--[[
	Steal a Egg — painel seguro para Roblox Studio
	Coloque este arquivo em StarterPlayer > StarterPlayerScripts.

	O cliente apenas mostra a lista e envia o alvo selecionado.
	A coleta, a movimentação e a recompensa são validadas no servidor.

	Cada alvo em workspace.Eggs deve ser um Model ou BasePart com:
	- Attribute "PetName" (string, opcional; usa o nome do objeto se faltar)
	- Attribute "IncomePerSecond" (number)
	- Attribute "PetImage" (string ou number com o asset da imagem, opcional)
]]

local Players = game:GetService("Players")
local ReplicatedStorage = game:GetService("ReplicatedStorage")
local UserInputService = game:GetService("UserInputService")

local player = Players.LocalPlayer
local playerGui = player:WaitForChild("PlayerGui")

local TARGET_FOLDER_NAME = "Eggs"
local REMOTES_FOLDER_NAME = "StealEggRemotes"
local REQUEST_REMOTE_NAME = "RequestStealEgg"
local STATUS_REMOTE_NAME = "StealEggStatus"
local TOGGLE_KEY = Enum.KeyCode.RightShift
local REFRESH_INTERVAL = 2

local targetFolder = workspace:FindFirstChild(TARGET_FOLDER_NAME)
local remotesFolder = ReplicatedStorage:WaitForChild(REMOTES_FOLDER_NAME)
local requestRemote = remotesFolder:WaitForChild(REQUEST_REMOTE_NAME)
local statusRemote = remotesFolder:WaitForChild(STATUS_REMOTE_NAME)

local oldGui = playerGui:FindFirstChild("StealEggPanel")
if oldGui then
	oldGui:Destroy()
end

local COLORS = {
	Background = Color3.fromRGB(16, 14, 22),
	Header = Color3.fromRGB(37, 19, 45),
	Card = Color3.fromRGB(29, 26, 38),
	CardHover = Color3.fromRGB(47, 35, 59),
	Selected = Color3.fromRGB(93, 45, 113),
	Accent = Color3.fromRGB(190, 96, 255),
	AccentDark = Color3.fromRGB(111, 47, 142),
	Text = Color3.fromRGB(245, 242, 250),
	Muted = Color3.fromRGB(176, 168, 190),
	Good = Color3.fromRGB(92, 224, 143),
	Bad = Color3.fromRGB(255, 112, 112),
}

local function addCorner(instance, radius)
	local corner = Instance.new("UICorner")
	corner.CornerRadius = UDim.new(0, radius)
	corner.Parent = instance
	return corner
end

local function addStroke(instance, color, thickness)
	local stroke = Instance.new("UIStroke")
	stroke.Color = color
	stroke.Thickness = thickness or 1
	stroke.Transparency = 0.15
	stroke.Parent = instance
	return stroke
end

local function isFiniteNumber(value)
	return typeof(value) == "number"
		and value == value
		and value > -math.huge
		and value < math.huge
end

local function getStringAttribute(instance, names, fallback)
	for _, attributeName in ipairs(names) do
		local value = instance:GetAttribute(attributeName)
		if typeof(value) == "string" and value ~= "" then
			return value
		end
	end
	return fallback
end

local function getNumberAttribute(instance, names, fallback)
	for _, attributeName in ipairs(names) do
		local value = instance:GetAttribute(attributeName)
		if isFiniteNumber(value) then
			return value
		end
	end
	return fallback
end

local function getImageValue(target)
	local value = target:GetAttribute("PetImage")
		or target:GetAttribute("Image")
		or target:GetAttribute("Thumbnail")

	if typeof(value) == "number" and isFiniteNumber(value) then
		return "rbxassetid://" .. tostring(math.floor(value))
	end

	if typeof(value) == "string" and value ~= "" then
		if value:match("^%d+$") then
			return "rbxassetid://" .. value
		end
		return value
	end

	return ""
end

local function getTargetData(target)
	local name = getStringAttribute(target, {"PetName", "DisplayName", "Pet"}, target.Name)
	local income = getNumberAttribute(target, {"IncomePerSecond", "CashPerSecond", "MoneyPerSecond"}, 0)
	return {
		name = name,
		income = math.max(0, income),
		image = getImageValue(target),
		target = target,
	}
end

local function formatIncome(value)
	if not isFiniteNumber(value) then
		return "$0/s"
	end

	local absolute = math.abs(value)
	if absolute >= 1000000000 then
		return string.format("$%.2fB/s", value / 1000000000)
	elseif absolute >= 1000000 then
		return string.format("$%.2fM/s", value / 1000000)
	elseif absolute >= 1000 then
		return string.format("$%.1fK/s", value / 1000)
	end

	return string.format("$%.0f/s", value)
end

local gui = Instance.new("ScreenGui")
gui.Name = "StealEggPanel"
gui.ResetOnSpawn = false
gui.IgnoreGuiInset = true
gui.ZIndexBehavior = Enum.ZIndexBehavior.Sibling
gui.Parent = playerGui

local panel = Instance.new("Frame")
panel.Name = "Main"
panel.Size = UDim2.fromOffset(310, 382)
panel.Position = UDim2.new(0, 18, 0.5, -191)
panel.BackgroundColor3 = COLORS.Background
panel.BorderSizePixel = 0
panel.Active = true
panel.Parent = gui
addCorner(panel, 14)
addStroke(panel, COLORS.Accent, 1.5)

local header = Instance.new("Frame")
header.Name = "Header"
header.Size = UDim2.new(1, 0, 0, 40)
header.BackgroundColor3 = COLORS.Header
header.BorderSizePixel = 0
header.Active = true
header.Parent = panel
addCorner(header, 14)

local title = Instance.new("TextLabel")
title.BackgroundTransparency = 1
title.Position = UDim2.fromOffset(12, 0)
title.Size = UDim2.new(1, -52, 1, 0)
title.Font = Enum.Font.GothamBold
title.Text = "Steal a Egg"
title.TextColor3 = COLORS.Text
title.TextSize = 16
title.TextXAlignment = Enum.TextXAlignment.Left
title.Parent = header

local subtitle = Instance.new("TextLabel")
subtitle.BackgroundTransparency = 1
subtitle.Position = UDim2.fromOffset(12, 25)
subtitle.Size = UDim2.new(1, -52, 0, 13)
subtitle.Font = Enum.Font.Gotham
subtitle.Text = "Escolha um pet para iniciar a coleta"
subtitle.TextColor3 = COLORS.Muted
subtitle.TextSize = 9
subtitle.TextXAlignment = Enum.TextXAlignment.Left
subtitle.Parent = header

local closeButton = Instance.new("TextButton")
closeButton.Name = "Close"
closeButton.Size = UDim2.fromOffset(28, 28)
closeButton.Position = UDim2.new(1, -34, 0, 6)
closeButton.BackgroundColor3 = COLORS.AccentDark
closeButton.BorderSizePixel = 0
closeButton.Font = Enum.Font.GothamBold
closeButton.Text = "×"
closeButton.TextColor3 = COLORS.Text
closeButton.TextSize = 18
closeButton.Parent = header
addCorner(closeButton, 7)

local list = Instance.new("ScrollingFrame")
list.Name = "PetList"
list.Position = UDim2.fromOffset(9, 48)
list.Size = UDim2.new(1, -18, 1, -139)
list.BackgroundTransparency = 1
list.BorderSizePixel = 0
list.ScrollBarThickness = 4
list.ScrollBarImageColor3 = COLORS.Accent
list.AutomaticCanvasSize = Enum.AutomaticSize.Y
list.CanvasSize = UDim2.fromOffset(0, 0)
list.ScrollingDirection = Enum.ScrollingDirection.Y
list.Parent = panel

local listLayout = Instance.new("UIListLayout")
listLayout.Padding = UDim.new(0, 5)
listLayout.SortOrder = Enum.SortOrder.LayoutOrder
listLayout.Parent = list

local listPadding = Instance.new("UIPadding")
listPadding.PaddingTop = UDim.new(0, 2)
listPadding.PaddingBottom = UDim.new(0, 4)
listPadding.PaddingLeft = UDim.new(0, 1)
listPadding.PaddingRight = UDim.new(0, 1)
listPadding.Parent = list

local statusLabel = Instance.new("TextLabel")
statusLabel.Name = "Status"
statusLabel.BackgroundTransparency = 1
statusLabel.Position = UDim2.new(0, 12, 1, -86)
statusLabel.Size = UDim2.new(1, -24, 0, 18)
statusLabel.Font = Enum.Font.Gotham
statusLabel.Text = "Nenhum pet selecionado"
statusLabel.TextColor3 = COLORS.Muted
statusLabel.TextSize = 11
statusLabel.TextTruncate = Enum.TextTruncate.AtEnd
statusLabel.TextXAlignment = Enum.TextXAlignment.Left
statusLabel.Parent = panel

local stealButton = Instance.new("TextButton")
stealButton.Name = "StealButton"
stealButton.Position = UDim2.new(0, 9, 1, -61)
stealButton.Size = UDim2.new(1, -18, 0, 43)
stealButton.BackgroundColor3 = COLORS.Accent
stealButton.BorderSizePixel = 0
stealButton.AutoButtonColor = true
stealButton.Font = Enum.Font.GothamBold
stealButton.Text = "Steal a Egg"
stealButton.TextColor3 = COLORS.Text
stealButton.TextSize = 15
stealButton.Parent = panel
addCorner(stealButton, 9)

local selectedTarget = nil
local rows = {}
local isWaitingForServer = false
local refreshQueued = false

local function setStatus(message, color)
	statusLabel.Text = message
	statusLabel.TextColor3 = color or COLORS.Muted
end

local function clearRows()
	for _, row in ipairs(rows) do
		if row and row.Parent then
			row:Destroy()
		end
	end
	table.clear(rows)
end

local function getTargets()
	local targets = {}
	if not targetFolder then
		return targets
	end

	for _, child in ipairs(targetFolder:GetChildren()) do
		if (child:IsA("Model") or child:IsA("BasePart")) and child:GetAttribute("Stolen") ~= true then
			table.insert(targets, getTargetData(child))
		end
	end

	table.sort(targets, function(left, right)
		if left.income == right.income then
			return string.lower(left.name) < string.lower(right.name)
		end
		return left.income > right.income
	end)

	return targets
end

local function updateRowSelection()
	for _, rowInfo in ipairs(rows) do
		if rowInfo.target == selectedTarget then
			rowInfo.button.BackgroundColor3 = COLORS.Selected
		else
			rowInfo.button.BackgroundColor3 = COLORS.Card
		end
	end
end

local function makeEmptyRow(message)
	local empty = Instance.new("TextLabel")
	empty.Size = UDim2.new(1, -4, 0, 42)
	empty.BackgroundTransparency = 1
	empty.Font = Enum.Font.Gotham
	empty.Text = message
	empty.TextColor3 = COLORS.Muted
	empty.TextSize = 12
	empty.Parent = list
	table.insert(rows, {button = empty, target = nil})
end

local function refreshList()
	refreshQueued = false
	clearRows()

	local targets = getTargets()
	if #targets == 0 then
		selectedTarget = nil
		setStatus("Nenhum pet disponível", COLORS.Muted)
		makeEmptyRow("Nenhum pet disponível")
		return
	end

	local selectedStillExists = false
	for index, data in ipairs(targets) do
		if data.target == selectedTarget then
			selectedStillExists = true
		end

		local row = Instance.new("TextButton")
		row.Name = "PetRow"
		row.LayoutOrder = index
		row.Size = UDim2.new(1, -4, 0, 48)
		row.BackgroundColor3 = COLORS.Card
		row.BorderSizePixel = 0
		row.AutoButtonColor = false
		row.Text = ""
		row.Parent = list
		addCorner(row, 8)

		local image = Instance.new("ImageLabel")
		image.Name = "PetImage"
		image.Position = UDim2.fromOffset(5, 5)
		image.Size = UDim2.fromOffset(38, 38)
		image.BackgroundColor3 = COLORS.Header
		image.BorderSizePixel = 0
		image.Image = data.image
		image.ScaleType = Enum.ScaleType.Fit
		image.Parent = row
		addCorner(image, 7)

		local nameLabel = Instance.new("TextLabel")
		nameLabel.BackgroundTransparency = 1
		nameLabel.Position = UDim2.fromOffset(51, 6)
		nameLabel.Size = UDim2.new(1, -142, 0, 18)
		nameLabel.Font = Enum.Font.GothamSemibold
		nameLabel.Text = data.name
		nameLabel.TextColor3 = COLORS.Text
		nameLabel.TextSize = 12
		nameLabel.TextTruncate = Enum.TextTruncate.AtEnd
		nameLabel.TextXAlignment = Enum.TextXAlignment.Left
		nameLabel.Parent = row

		local incomeLabel = Instance.new("TextLabel")
		incomeLabel.BackgroundTransparency = 1
		incomeLabel.Position = UDim2.new(1, -92, 0, 13)
		incomeLabel.Size = UDim2.fromOffset(86, 20)
		incomeLabel.Font = Enum.Font.GothamBold
		incomeLabel.Text = formatIncome(data.income)
		incomeLabel.TextColor3 = COLORS.Good
		incomeLabel.TextSize = 11
		incomeLabel.TextXAlignment = Enum.TextXAlignment.Right
		incomeLabel.Parent = row

		local hintLabel = Instance.new("TextLabel")
		hintLabel.BackgroundTransparency = 1
		hintLabel.Position = UDim2.fromOffset(51, 25)
		hintLabel.Size = UDim2.new(1, -148, 0, 15)
		hintLabel.Font = Enum.Font.Gotham
		hintLabel.Text = "Clique para selecionar"
		hintLabel.TextColor3 = COLORS.Muted
		hintLabel.TextSize = 9
		hintLabel.TextXAlignment = Enum.TextXAlignment.Left
		hintLabel.Parent = row

		row.MouseEnter:Connect(function()
			if data.target ~= selectedTarget then
				row.BackgroundColor3 = COLORS.CardHover
			end
		end)
	row.MouseLeave:Connect(function()
			if data.target ~= selectedTarget then
				row.BackgroundColor3 = COLORS.Card
			end
		end)

		row.Activated:Connect(function()
			selectedTarget = data.target
			setStatus("Selecionado: " .. data.name, COLORS.Text)
			updateRowSelection()
		end)

		table.insert(rows, {button = row, target = data.target})
	end

	if not selectedStillExists then
		selectedTarget = nil
		setStatus("Nenhum pet selecionado", COLORS.Muted)
	else
		updateRowSelection()
	end
end

local function queueRefresh()
	if refreshQueued then
		return
	end
	refreshQueued = true
	task.defer(refreshList)
end

closeButton.Activated:Connect(function()
	panel.Visible = false
end)

stealButton.Activated:Connect(function()
	if isWaitingForServer then
		return
	end

	if not selectedTarget or not selectedTarget.Parent then
		setStatus("Selecione um pet primeiro", COLORS.Bad)
		return
	end

	isWaitingForServer = true
	stealButton.Active = false
	stealButton.AutoButtonColor = false
	stealButton.BackgroundColor3 = COLORS.AccentDark
	stealButton.Text = "Aguardando servidor..."
	setStatus("Pedido enviado; aguardando validação", COLORS.Muted)
	requestRemote:FireServer(selectedTarget)
end)

statusRemote.OnClientEvent:Connect(function(kind, message)
	if typeof(message) ~= "string" then
		message = "Resposta do servidor recebida"
	end

	if kind == "Started" or kind == "Moving" or kind == "Returning" then
		setStatus(message, COLORS.Muted)
	elseif kind == "Success" then
		setStatus(message, COLORS.Good)
		selectedTarget = nil
		queueRefresh()
	elseif kind == "Error" then
		setStatus(message, COLORS.Bad)
	end

	if kind == "Success" or kind == "Error" then
		isWaitingForServer = false
		stealButton.Active = true
		stealButton.AutoButtonColor = true
		stealButton.BackgroundColor3 = COLORS.Accent
		stealButton.Text = "Steal a Egg"
	end
end)

if targetFolder then
	targetFolder.ChildAdded:Connect(queueRefresh)
	targetFolder.ChildRemoved:Connect(queueRefresh)
else
	setStatus("Crie workspace.Eggs para exibir os pets", COLORS.Bad)
end

UserInputService.InputBegan:Connect(function(input, gameProcessed)
	if gameProcessed then
		return
	end
	if input.KeyCode == TOGGLE_KEY then
		panel.Visible = not panel.Visible
	end
end)

-- Arrastar o painel pelo cabeçalho.
local dragging = false
local dragStart = nil
local startPosition = nil

header.InputBegan:Connect(function(input)
	if input.UserInputType == Enum.UserInputType.MouseButton1
		or input.UserInputType == Enum.UserInputType.Touch then
		dragging = true
		dragStart = input.Position
		startPosition = panel.Position
	end
end)

UserInputService.InputChanged:Connect(function(input)
	if not dragging then
		return
	end
	if input.UserInputType == Enum.UserInputType.MouseMovement
		or input.UserInputType == Enum.UserInputType.Touch then
		local delta = input.Position - dragStart
		panel.Position = UDim2.new(
			startPosition.X.Scale,
			startPosition.X.Offset + delta.X,
			startPosition.Y.Scale,
			startPosition.Y.Offset + delta.Y
		)
	end
end)

UserInputService.InputEnded:Connect(function(input)
	if input.UserInputType == Enum.UserInputType.MouseButton1
		or input.UserInputType == Enum.UserInputType.Touch then
		dragging = false
	end
end)

task.spawn(function()
	while gui.Parent do
		task.wait(REFRESH_INTERVAL)
		if gui.Parent then
			refreshList()
		end
	end
end)

refreshList()
