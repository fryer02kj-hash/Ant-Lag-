# Steal a Egg — análise e versão segura

## Limite importante

O arquivo original é um **LocalScript para executor**. Ele tenta alterar a velocidade do personagem, acionar `fireproximityprompt` e mover o `HumanoidRootPart` com `CFrame`. Isso é apropriado apenas como diagnóstico de código; não é uma base segura para roubar itens de uma experiência de terceiros.

A versão entregue aqui é para **Roblox Studio e uma experiência que você controla**. Ela mantém a ideia visual do pedido — painel pequeno, foto do pet, renda por segundo, ordenação do maior para o menor, seleção e botão **Steal a Egg** — mas troca a lógica de exploração por um fluxo cliente-servidor validado.

## O que havia no script original

1. **A lista não era de pets.** `findEggs()` vasculhava o `Workspace` procurando objetos cujo nome contivesse `egg` ou `ovo`. O painel mostrava o nome do objeto, mas não uma imagem nem uma renda real por segundo.
2. **O valor era apenas estimado.** `estimateValue()` deduzia um valor pelo nome da raridade ou pelo tamanho físico do objeto. Isso pode ordenar errado e não representa uma economia real do jogo.
3. **A velocidade vinha do cliente.** `getMaxSpeed()` procurava atributos e `NumberValue` para escolher a maior velocidade e depois escrevia em `Humanoid.WalkSpeed`. Um cliente não deve definir a própria velocidade em uma ação que entrega recompensa.
4. **A interação era dependente de executor.** `fireproximityprompt(prompt)` não é uma API de jogo confiável para um fluxo normal de Studio. Além disso, o script também forçava a posição com `root.CFrame`, o que ignora obstáculos e validações do jogo.
5. **Não havia autoridade do servidor.** O script não validava propriedade, distância, estado do ovo, cooldown, concorrência ou recompensa no servidor.
6. **A atualização era custosa e frágil.** A cada ciclo, todos os botões eram destruídos e recriados, e a busca recursiva podia encontrar objetos não relacionados.

## Arquivos entregues

- `StealEgg_Painel_Seguro.client.lua`: coloque em `StarterPlayer > StarterPlayerScripts`.
- `StealEgg_Servico_Seguro.server.lua`: coloque em `ServerScriptService`.

O serviço cria automaticamente em `ReplicatedStorage`:

```text
StealEggRemotes
├── RequestStealEgg   (RemoteEvent)
└── StealEggStatus    (RemoteEvent)
```

## Estrutura mínima no Studio

Crie uma pasta `workspace.Eggs`. Cada ovo deve ser um `Model` ou `BasePart` filho direto dessa pasta. Defina estes atributos no objeto:

```text
PetName           string       opcional; usa o nome do objeto se faltar
IncomePerSecond   number       obrigatório para exibir a renda correta
PetImage          string/number opcional; URL Roblox ou ID do asset da imagem
```

Exemplo de configuração no Command Bar ou em um Script de teste:

```lua
local egg = workspace.Eggs:WaitForChild("GoldenEgg")
egg:SetAttribute("PetName", "Golden Fox")
egg:SetAttribute("IncomePerSecond", 1250)
egg:SetAttribute("PetImage", "rbxassetid://1234567890")
```

Para o retorno, use uma destas estruturas:

```text
workspace
├── Eggs
└── Plots
    └── PlotDoJogador
        ├── ReturnPoint (Part)
        └── atributo OwnerUserId = UserId do jogador
```

O serviço também aceita `OwnerId`, `Owner` ou um plot com o mesmo nome do jogador. Se não houver plots, crie `workspace.ReturnPoint`.

## Como o fluxo funciona

1. O painel lê somente os filhos de `workspace.Eggs`.
2. Cada linha mostra a imagem `PetImage`, o nome do pet e `IncomePerSecond` formatado como `/s`.
3. A lista é ordenada pela maior renda. Em empate, ordena pelo nome.
4. Ao clicar em **Steal a Egg**, o cliente envia apenas a referência do objeto selecionado ao `RemoteEvent`.
5. O servidor confirma que a referência é uma instância real, que está dentro da pasta correta, que não foi coletada e que não está reservada para outra pessoa.
6. O servidor calcula um caminho com `PathfindingService` e usa `Humanoid:MoveTo`. Não há `CFrame` para atravessar o mapa.
7. Depois de chegar dentro do raio configurado, o servidor cria um registro simples em `player.EggInventory`, destrói o ovo e manda o personagem retornar ao ponto configurado.
8. `grantEgg()` é o ponto de integração com o inventário e o DataStore reais do seu jogo. O exemplo não persiste dados entre servidores.

## Ajustes principais

No serviço do servidor:

```lua
StealSpeed = 24
CooldownSeconds = 2
MaxTripDistance = 2000
PickupRadius = 10
```

`StealSpeed` é uma velocidade definida pelo jogo. Não substitua por uma leitura de velocidade enviada pelo cliente. Se o seu jogo tem uma velocidade própria, altere a configuração no servidor.

Se o mapa tiver corredores estreitos, ajuste `AgentRadius`, `AgentHeight`, `AgentCanJump` e `WaypointSpacing`. Se o caminho for bloqueado, o serviço encerra a tentativa em vez de teletransportar o jogador.

## Melhorias de segurança incluídas

- validação de tipo e de hierarquia do alvo;
- validação de atributos numéricos, incluindo rejeição de `NaN` e infinito;
- limite de distância da viagem;
- cooldown por jogador;
- uma operação por jogador;
- reserva do ovo durante a coleta;
- recompensa concedida no servidor;
- restauração da velocidade original ao terminar ou falhar;
- nenhuma dependência de executor, `fireproximityprompt` ou teleporte por `CFrame`.

A documentação oficial do Roblox recomenda validar no servidor todos os dados enviados por clientes, incluindo tipo, estrutura, valores, distância, tempo e permissões. Isso se aplica a `RemoteEvents` e também a interações como `ProximityPrompt`. [1] [2]

O `RemoteEvent` recebe no servidor o jogador que fez a chamada em `OnServerEvent`, enquanto o cliente pode iniciar a solicitação com `FireServer`. [3]

Para o deslocamento, o script usa `PathfindingService:CreatePath()` e `Path:ComputeAsync()` para obter um caminho com waypoints, em vez de mover o personagem diretamente por `CFrame`. [4]

A foto do pet é um asset configurado no atributo `PetImage`. A API `Players:GetUserThumbnailAsync()` é voltada para thumbnails de usuários; por isso, para pets do jogo é mais simples e previsível usar uma imagem Roblox própria no atributo. [5]

## Referências

[1]: https://create.roblox.com/docs/scripting/security/client-server-boundary "Securing the client-server boundary"
[2]: https://create.roblox.com/docs/reference/engine/classes/ProximityPrompt "ProximityPrompt"
[3]: https://create.roblox.com/docs/reference/engine/classes/RemoteEvent "RemoteEvent"
[4]: https://create.roblox.com/docs/reference/engine/classes/PathfindingService "PathfindingService"
[5]: https://create.roblox.com/docs/reference/engine/classes/Players "Players — GetUserThumbnailAsync"
