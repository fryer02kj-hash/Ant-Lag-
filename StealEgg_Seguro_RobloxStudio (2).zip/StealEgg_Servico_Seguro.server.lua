--[[
	Steal a Egg — serviço seguro do servidor para Roblox Studio
	Coloque este arquivo em ServerScriptService.

	Este Script é a autoridade da operação. Ele:
	- rejeita alvos que não estejam em workspace.Eggs;
	- rejeita alvos reservados, destruídos ou já coletados;
	- usa PathfindingService + Humanoid:MoveTo, sem CFrame e sem teleporte;
	- usa uma velocidade configurada pelo jogo, não uma velocidade "detectada" do cliente;
	- concede uma recompensa simples em player.EggInventory;
	- aplica cooldown e impede duas coletas simultâneas por jogador.

	Adapte grantEgg() ao seu sistema real de inventário/DataStore.
]]

local Players = game:GetService("Players")
local ReplicatedStorage = game:GetService("ReplicatedStorage")
local PathfindingService = game:GetService("PathfindingService")
local Workspace = game:GetService("Workspace")

local CONFIG = {
	TargetFolderName = "Eggs",
	RemotesFolderName = "StealEggRemotes",
	RequestRemoteName = "RequestStealEgg",
	StatusRemoteName = "StealEggStatus",

	-- Velocidade legítima do modo de coleta do seu jogo.
	StealSpeed = 24,
	CooldownSeconds = 2,
	MaxTripDistance = 2000,
	PickupRadius = 10,
	ArrivalRadius = 5,
	WaypointTimeout = 8,
	MaxIncomePerSecond = 1000000000000,

	AgentParameters = {
		AgentRadius = 2,
		AgentHeight = 5,
		AgentCanJump = true,
		WaypointSpacing = 4,
	},

	ReturnPointNames = {"ReturnPoint", "Spawn", "SpawnLocation"},
}

local targetFolder = Workspace:FindFirstChild(CONFIG.TargetFolderName)
if not targetFolder then
	warn("[StealEgg] Crie workspace." .. CONFIG.TargetFolderName .. " para armazenar os ovos.")
end

local remotesFolder = ReplicatedStorage:FindFirstChild(CONFIG.RemotesFolderName)
if not remotesFolder then
	remotesFolder = Instance.new("Folder")
	remotesFolder.Name = CONFIG.RemotesFolderName
	remotesFolder.Parent = ReplicatedStorage
end

local requestRemote = remotesFolder:FindFirstChild(CONFIG.RequestRemoteName)
if not requestRemote then
	requestRemote = Instance.new("RemoteEvent")
	requestRemote.Name = CONFIG.RequestRemoteName
	requestRemote.Parent = remotesFolder
end

local statusRemote = remotesFolder:FindFirstChild(CONFIG.StatusRemoteName)
if not statusRemote then
	statusRemote = Instance.new("RemoteEvent")
	statusRemote.Name = CONFIG.StatusRemoteName
	statusRemote.Parent = remotesFolder
end

local busyPlayers = {}
local lastRequestAt = {}

local function sendStatus(player, kind, message)
	if player and player.Parent then
		statusRemote:FireClient(player, kind, message)
	end
end

local function isFiniteNumber(value)
	return typeof(value) == "number"
		and value == value
		and value > -math.huge
		and value < math.huge
end

local function getStringAttribute(instance, names, fallback)
	for _, attributeName in ipairs(names) do
		local value = instance:GetAttribute(attributeName)
		if typeof(value) == "string" and value ~= "" and #value <= 80 then
			return value
		end
	end
	return fallback
end

local function getIncomePerSecond(target)
	local value = target:GetAttribute("IncomePerSecond")
	if not isFiniteNumber(value) then
		value = target:GetAttribute("CashPerSecond")
	end

	if not isFiniteNumber(value) then
		local numberValue = target:FindFirstChild("IncomePerSecond")
		if numberValue and numberValue:IsA("NumberValue") then
			value = numberValue.Value
		end
	end

	if not isFiniteNumber(value) then
		value = 0
	end

	return math.clamp(value, 0, CONFIG.MaxIncomePerSecond)
end

local function getPosition(instance)
	if not instance then
		return nil
	end

	if instance:IsA("BasePart") then
		return instance.Position
	end

	if instance:IsA("Model") then
		local ok, pivot = pcall(function()
			return instance:GetPivot()
		end)
		if ok and pivot then
			return pivot.Position
		end
	end

	return nil
end

local function getCharacterParts(player)
	local character = player.Character
	if not character then
		return nil, nil, nil
	end

	local humanoid = character:FindFirstChildOfClass("Humanoid")
	local root = character:FindFirstChild("HumanoidRootPart")
	if not humanoid or not root or humanoid.Health <= 0 then
		return nil, nil, nil
	end

	return character, humanoid, root
end

local function isValidTarget(target)
	if not targetFolder then
		return false, "A pasta de ovos não existe."
	end
	if typeof(target) ~= "Instance" then
		return false, "Alvo inválido."
	end
	if not (target:IsA("Model") or target:IsA("BasePart")) then
		return false, "O alvo precisa ser um Model ou BasePart."
	end
	if target.Parent ~= targetFolder then
		return false, "O alvo não pertence à lista de ovos."
	end
	if target:GetAttribute("Stolen") == true then
		return false, "Esse ovo já foi coletado."
	end
	if target:GetAttribute("ReservedBy") ~= nil then
		return false, "Esse ovo está sendo coletado por outro jogador."
	end

	local income = getIncomePerSecond(target)
	if not isFiniteNumber(income) or income < 0 or income > CONFIG.MaxIncomePerSecond then
		return false, "A renda do ovo é inválida."
	end

	if not getPosition(target) then
		return false, "Não foi possível localizar o ovo."
	end

	return true
end

local function getReturnPosition(player)
	local plots = Workspace:FindFirstChild("Plots")
	if plots then
		for _, plot in ipairs(plots:GetChildren()) do
			local ownerId = plot:GetAttribute("OwnerUserId")
				or plot:GetAttribute("OwnerId")
			local owner = plot:GetAttribute("Owner")

			if ownerId == player.UserId
				or owner == player.UserId
				or owner == player.Name
				or plot.Name == player.Name then
				for _, pointName in ipairs(CONFIG.ReturnPointNames) do
					local point = plot:FindFirstChild(pointName, true)
					local position = getPosition(point)
					if position then
						return position + Vector3.new(0, 2, 0)
					end
				end

				local plotPosition = getPosition(plot)
				if plotPosition then
					return plotPosition + Vector3.new(0, 3, 0)
				end
			end
		end
	end

	local globalReturnPoint = Workspace:FindFirstChild("ReturnPoint", true)
	local globalPosition = getPosition(globalReturnPoint)
	if globalPosition then
		return globalPosition + Vector3.new(0, 2, 0)
	end

	local _, _, root = getCharacterParts(player)
	return root and root.Position or nil
end

local function moveToPosition(player, destination)
	local _, humanoid, root = getCharacterParts(player)
	if not humanoid or not root then
		return false, "O personagem não está disponível."
	end

	if typeof(destination) ~= "Vector3" then
		return false, "Destino inválido."
	end

	local path = PathfindingService:CreatePath(CONFIG.AgentParameters)
	local success, errorMessage = pcall(function()
		path:ComputeAsync(root.Position, destination)
	end)

	if not success or path.Status ~= Enum.PathStatus.Success then
		warn("[StealEgg] Falha ao calcular caminho:", errorMessage or path.Status.Name)
		return false, "Não foi possível encontrar um caminho."
	end

	local waypoints = path:GetWaypoints()
	for _, waypoint in ipairs(waypoints) do
		local _, currentHumanoid, currentRoot = getCharacterParts(player)
		if currentHumanoid ~= humanoid or not currentRoot then
			return false, "O personagem mudou durante a coleta."
		end

		if waypoint.Action == Enum.PathWaypointAction.Jump then
			currentHumanoid.Jump = true
		end

		currentHumanoid:MoveTo(waypoint.Position)
		local deadline = os.clock() + CONFIG.WaypointTimeout
		local reached = false

		while os.clock() < deadline do
			if currentHumanoid.Health <= 0 then
				return false, "O personagem morreu durante a coleta."
			end
			if (currentRoot.Position - waypoint.Position).Magnitude <= CONFIG.ArrivalRadius then
				reached = true
				break
			end
			task.wait(0.1)
		end

		if not reached then
			return false, "O caminho foi interrompido."
		end
	end

	return true
end

local function grantEgg(player, target)
	if not target or not target.Parent then
		return false, "O ovo deixou de existir."
	end

	local petName = getStringAttribute(target, {"PetName", "DisplayName", "Pet"}, target.Name)
	local income = getIncomePerSecond(target)
	local image = target:GetAttribute("PetImage")

	-- Exemplo mínimo de inventário. Troque por InventoryService/DataStore do seu jogo.
	local inventory = player:FindFirstChild("EggInventory")
	if not inventory then
		inventory = Instance.new("Folder")
		inventory.Name = "EggInventory"
		inventory.Parent = player
	end

	local item = Instance.new("Folder")
	item.Name = "Pet_" .. target.Name
	item:SetAttribute("PetName", petName)
	item:SetAttribute("IncomePerSecond", income)
	if typeof(image) == "string" or typeof(image) == "number" then
		item:SetAttribute("PetImage", image)
	end
	item.Parent = inventory

	target:SetAttribute("Stolen", true)
	target:Destroy()
	return true
end

local function runSteal(player, target)
	local _, humanoid, root = getCharacterParts(player)
	if not humanoid or not root then
		sendStatus(player, "Error", "Seu personagem não está pronto.")
		return
	end

	local targetPosition = getPosition(target)
	local returnPosition = getReturnPosition(player)
	if not targetPosition or not returnPosition then
		sendStatus(player, "Error", "Configure o ovo e o ponto de retorno.")
		return
	end

	if (root.Position - targetPosition).Magnitude > CONFIG.MaxTripDistance then
		sendStatus(player, "Error", "O ovo está fora do alcance permitido.")
		return
	end

	local oldWalkSpeed = humanoid.WalkSpeed
	local speedChanged = false
	if isFiniteNumber(CONFIG.StealSpeed) and CONFIG.StealSpeed > 0 then
		humanoid.WalkSpeed = CONFIG.StealSpeed
		speedChanged = true
	end

	local function restoreSpeed()
		if speedChanged and humanoid and humanoid.Parent then
			humanoid.WalkSpeed = oldWalkSpeed
		end
	end

	sendStatus(player, "Moving", "Indo até " .. target.Name .. "...")
	local reachedTarget, moveError = moveToPosition(player, targetPosition)
	if not reachedTarget then
		restoreSpeed()
		sendStatus(player, "Error", moveError)
		return
	end

	local _, currentHumanoid, currentRoot = getCharacterParts(player)
	if not currentHumanoid or not currentRoot or (currentRoot.Position - targetPosition).Magnitude > CONFIG.PickupRadius then
		restoreSpeed()
		sendStatus(player, "Error", "A coleta precisa acontecer perto do ovo.")
		return
	end

	if not target.Parent or target:GetAttribute("ReservedBy") ~= player.UserId then
		restoreSpeed()
		sendStatus(player, "Error", "O ovo não está mais disponível.")
		return
	end

	sendStatus(player, "Started", "Coletando " .. target.Name .. "...")
	local granted, grantError = grantEgg(player, target)
	if not granted then
		restoreSpeed()
		sendStatus(player, "Error", grantError)
		return
	end

	sendStatus(player, "Returning", "Ovo coletado; voltando...")
	local returned, returnError = moveToPosition(player, returnPosition)
	restoreSpeed()

	if returned then
		sendStatus(player, "Success", "Ovo entregue com sucesso.")
	else
		-- A recompensa já foi concedida; o erro informa que o retorno falhou.
		sendStatus(player, "Error", "Ovo coletado, mas o retorno falhou: " .. returnError)
	end
end

requestRemote.OnServerEvent:Connect(function(player, target)
	if busyPlayers[player] then
		sendStatus(player, "Error", "Você já está coletando um ovo.")
		return
	end

	local now = os.clock()
	local previousRequest = lastRequestAt[player] or 0
	if now - previousRequest < CONFIG.CooldownSeconds then
		sendStatus(player, "Error", "Aguarde um instante antes de tentar novamente.")
		return
	end
	lastRequestAt[player] = now

	local valid, reason = isValidTarget(target)
	if not valid then
		sendStatus(player, "Error", reason)
		return
	end

	local _, _, root = getCharacterParts(player)
	if not root then
		sendStatus(player, "Error", "Seu personagem não está pronto.")
		return
	end

	busyPlayers[player] = true
	target:SetAttribute("ReservedBy", player.UserId)
	sendStatus(player, "Started", "Pedido validado pelo servidor.")

	task.spawn(function()
		local ok, errorMessage = xpcall(function()
			runSteal(player, target)
		end, debug.traceback)

		if not ok then
			warn("[StealEgg] Erro inesperado:\n" .. tostring(errorMessage))
			sendStatus(player, "Error", "Ocorreu um erro durante a coleta.")
		end

		if target and target.Parent and target:GetAttribute("ReservedBy") == player.UserId then
			target:SetAttribute("ReservedBy", nil)
		end
		busyPlayers[player] = nil
	end)
end)

Players.PlayerRemoving:Connect(function(player)
	busyPlayers[player] = nil
	lastRequestAt[player] = nil
end)
